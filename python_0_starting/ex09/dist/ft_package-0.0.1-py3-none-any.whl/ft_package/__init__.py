def count_in_list(lst, elem):
    return lst.count(elem)
